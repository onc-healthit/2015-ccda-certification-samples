Enclosed within this folder is Health Summary document of Alice Newman. 
 
Open the Alice_Newman_health_summary.xml file in the Internet Explorer Browser.


Thank you.