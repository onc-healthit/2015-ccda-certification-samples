Enclosed within this folder is Health Summary document of Jeremy Bates. 
 
Open the Jeremy_Bates_health_summary.xml file in the Internet Explorer Browser.


Thank you.